

## Assignment #1

### Coding
sketch1:https://editor.p5js.org/Lucacacacacaca/sketches/uR32ZVX2b

![6c6c457b94288db70f41344ae2f7063](https://git.arts.ac.uk/24001444/CCI-Course-Notebook/assets/1324/b430aab7-3da5-4238-9268-1b8cb83c3427)
