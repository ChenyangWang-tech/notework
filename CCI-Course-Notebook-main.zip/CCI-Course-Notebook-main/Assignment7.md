## Assignment #7

**Sketching**

sluggishness

![1f92537782de5f47dd303bf54f47534](https://git.arts.ac.uk/24001444/CCI-Course-Notebook/assets/1324/5f319613-8960-4ce5-b99c-ad06fb43f01c)


**Researching**

I choose Reface [Portrait Sequencer]. This work utilises computer vision, real-time video processing and facial recognition technology to explore the dynamics of the human face and the deeper cultural, social and psychological meanings behind it by allowing the viewer to interact with the work.

I like how this interactivity emphasises the fusion of technology and art. The audience's participation not only makes the work a process of self-expression, but also creates uncertainty and a greater sense of engagement with the content and presentation of the work, and reinforces the discussion of identity and the fluidity of individuality. However, I will choose to reduce the personal characteristics of the face and try to make an extreme simplification. There is an old Chinese saying that ‘the face is born from the heart’, which means that a person's outward appearance is influenced by his or her inner heart or state of mind. This can also lead us to fall into appearance bias when getting to know a person. I'm curious how people would react to the simplification of the face.


**Coding**
https://editor.p5js.org/Lucacacacacaca/sketches/pKAMRiSLN
